#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy2 Experiment Builder (v1.84.1),
    on Thu  9 Aug 12:49:19 2018
If you publish work using this script please cite the PsychoPy publications:
    Peirce, JW (2007) PsychoPy - Psychophysics software in Python.
        Journal of Neuroscience Methods, 162(1-2), 8-13.
    Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy.
        Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import absolute_import, division
from psychopy import locale_setup, gui, visual, core, data, event, logging, sound
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__)).decode(sys.getfilesystemencoding())
os.chdir(_thisDir)

# Store info about the experiment session
expName = 'positioneffect'  # from the Builder filename that created this script
expInfo = {'participant':'', 'session':'001'}
dlg = gui.DlgFromDict(dictionary=expInfo, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=None,
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation
loopCounter = 0
# Setup the Window
win = visual.Window(
    size=(1920, 1080), fullscr=True, screen=0,
    allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Initialize components for Routine "instructions"
instructionsClock = core.Clock()
Instruction = visual.TextStim(win=win, name='Instruction',
    text=u"Hello!\n\n In this experiment, you will fixate on the cross in the center of the screen while an image of either an eye or a mouth will appear. You will then be presented with two images, and you will select which image matches the one you previously saw. When making your choice, press either the '1' for the image on the left side or the '2' key for the image on the right side. Use the numbers on the numberpad on the right side of your keyboard.\n\nYou will first complete some trials to get used to the experiment.\nPlease do not forget to fixate on the cross in the center of the screen.\n\nPress space to begin.",
    font=u'Arial',
    pos=[0, 0], height=0.03, wrapWidth=None, ori=0, 
    color=u'white', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "practice"
practiceClock = core.Clock()
practice_target = visual.ImageStim(
    win=win, name='practice_target',
    image='sin', mask=None,
    ori=0, pos=[0,0], size=None,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
practice_stim1 = visual.ImageStim(
    win=win, name='practice_stim1',
    image='sin', mask=None,
    ori=0, pos=[0,0], size=None,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
practice_stim2 = visual.ImageStim(
    win=win, name='practice_stim2',
    image='sin', mask=None,
    ori=0, pos=[0,0], size=None,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
practice_fixation = visual.ImageStim(
    win=win, name='practice_fixation',
    image='fixation_cross.png', mask=None,
    ori=0, pos=(0, 0), size=(0.03, 0.05),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)
practice_mask = visual.ImageStim(
    win=win, name='practice_mask',
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(0.5, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-5.0)

# Initialize components for Routine "practice_feedback"
practice_feedbackClock = core.Clock()
feedback = visual.TextStim(win=win, name='feedback',
    text='default text',
    font=u'Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color=u'white', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "starting"
startingClock = core.Clock()
starting_brief = visual.TextStim(win=win, name='starting_brief',
    text=u"You are now about to begin the experiment. Please remember to fixate on the cross in the center of the screen, and don't forget to take a break in between blocks of trials.\n\nPress the space bar to begin.",
    font=u'Arial',
    pos=(0, 0), height=0.03, wrapWidth=None, ori=0, 
    color=u'white', colorSpace='rgb', opacity=1,
    depth=0.0);

# Initialize components for Routine "trial"
trialClock = core.Clock()
target1 = visual.ImageStim(
    win=win, name='target1',
    image='sin', mask=None,
    ori=0, pos=[0,0], size=None,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
stimulus_1 = visual.ImageStim(
    win=win, name='stimulus_1',
    image='sin', mask=None,
    ori=0, pos=[0,0], size=None,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
stimulus_2 = visual.ImageStim(
    win=win, name='stimulus_2',
    image='sin', mask=None,
    ori=0, pos=[0,0], size=None,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
fixation = visual.ImageStim(
    win=win, name='fixation',
    image='fixation_cross.png', mask=None,
    ori=0, pos=[0, 0], size=[0.03, 0.05],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)
mask_real = visual.ImageStim(
    win=win, name='mask_real',
    image='sin', mask=None,
    ori=0, pos=[0,0], size=[0.5, 0.3],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-5.0)

# Initialize components for Routine "debrief"
debriefClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text=u'You have completed the study. Thanks!',
    font=u'Arial',
    pos=[0, 0], height=0.05, wrapWidth=None, ori=0, 
    color=u'white', colorSpace='rgb', opacity=1,
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "instructions"-------
t = 0
instructionsClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
begin_practice = event.BuilderKeyResponse()
# keep track of which components have finished
instructionsComponents = [Instruction, begin_practice]
for thisComponent in instructionsComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "instructions"-------
while continueRoutine:
    # get current time
    t = instructionsClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *Instruction* updates
    if t >= 0.0 and Instruction.status == NOT_STARTED:
        # keep track of start time/frame for later
        Instruction.tStart = t
        Instruction.frameNStart = frameN  # exact frame index
        Instruction.setAutoDraw(True)
    
    # *begin_practice* updates
    if t >= 0.0 and begin_practice.status == NOT_STARTED:
        # keep track of start time/frame for later
        begin_practice.tStart = t
        begin_practice.frameNStart = frameN  # exact frame index
        begin_practice.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(begin_practice.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if begin_practice.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            begin_practice.keys = theseKeys[-1]  # just the last key pressed
            begin_practice.rt = begin_practice.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructionsComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instructions"-------
for thisComponent in instructionsComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if begin_practice.keys in ['', [], None]:  # No response was made
    begin_practice.keys=None
thisExp.addData('begin_practice.keys',begin_practice.keys)
if begin_practice.keys != None:  # we had a response
    thisExp.addData('begin_practice.rt', begin_practice.rt)
thisExp.nextEntry()
# the Routine "instructions" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
practice_loop = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('practice_trials.xlsx'),
    seed=None, name='practice_loop')
thisExp.addLoop(practice_loop)  # add the loop to the experiment
thisPractice_loop = practice_loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisPractice_loop.rgb)
if thisPractice_loop != None:
    for paramName in thisPractice_loop.keys():
        exec(paramName + '= thisPractice_loop.' + paramName)

for thisPractice_loop in practice_loop:
    currentLoop = practice_loop
    # abbreviate parameter names if possible (e.g. rgb = thisPractice_loop.rgb)
    if thisPractice_loop != None:
        for paramName in thisPractice_loop.keys():
            exec(paramName + '= thisPractice_loop.' + paramName)
    
    # ------Prepare to start Routine "practice"-------
    t = 0
    practiceClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    practice_target.setPos(region)
    practice_target.setImage(target)
    practice_stim1.setPos(stim1pos)
    practice_stim1.setImage(stimulus1)
    practice_stim2.setPos(stim2pos)
    practice_stim2.setImage(stimulus2)
    practice_response = event.BuilderKeyResponse()
    practice_mask.setPos(region)
    practice_mask.setImage(u'mask.gif')
    # keep track of which components have finished
    practiceComponents = [practice_target, practice_stim1, practice_stim2, practice_fixation, practice_response, practice_mask]
    for thisComponent in practiceComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "practice"-------
    while continueRoutine:
        # get current time
        t = practiceClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *practice_target* updates
        if t >= 0.5 and practice_target.status == NOT_STARTED:
            # keep track of start time/frame for later
            practice_target.tStart = t
            practice_target.frameNStart = frameN  # exact frame index
            practice_target.setAutoDraw(True)
        frameRemains = 0.5 + 0.2- win.monitorFramePeriod * 0.75  # most of one frame period left
        if practice_target.status == STARTED and t >= frameRemains:
            practice_target.setAutoDraw(False)
        
        # *practice_stim1* updates
        if t >= 1.15 and practice_stim1.status == NOT_STARTED:
            # keep track of start time/frame for later
            practice_stim1.tStart = t
            practice_stim1.frameNStart = frameN  # exact frame index
            practice_stim1.setAutoDraw(True)
        
        # *practice_stim2* updates
        if t >= 1.15 and practice_stim2.status == NOT_STARTED:
            # keep track of start time/frame for later
            practice_stim2.tStart = t
            practice_stim2.frameNStart = frameN  # exact frame index
            practice_stim2.setAutoDraw(True)
        
        # *practice_fixation* updates
        if t >= 0 and practice_fixation.status == NOT_STARTED:
            # keep track of start time/frame for later
            practice_fixation.tStart = t
            practice_fixation.frameNStart = frameN  # exact frame index
            practice_fixation.setAutoDraw(True)
        
        # *practice_response* updates
        if t >= 1.15 and practice_response.status == NOT_STARTED:
            # keep track of start time/frame for later
            practice_response.tStart = t
            practice_response.frameNStart = frameN  # exact frame index
            practice_response.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(practice_response.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if practice_response.status == STARTED:
            theseKeys = event.getKeys(keyList=['num_1', 'num_2'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                practice_response.keys = theseKeys[-1]  # just the last key pressed
                practice_response.rt = practice_response.clock.getTime()
                # was this 'correct'?
                if (practice_response.keys == str(correctAnswer)) or (practice_response.keys == correctAnswer):
                    practice_response.corr = 1
                else:
                    practice_response.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *practice_mask* updates
        if t >= 0.7 and practice_mask.status == NOT_STARTED:
            # keep track of start time/frame for later
            practice_mask.tStart = t
            practice_mask.frameNStart = frameN  # exact frame index
            practice_mask.setAutoDraw(True)
        frameRemains = 0.7 + .45- win.monitorFramePeriod * 0.75  # most of one frame period left
        if practice_mask.status == STARTED and t >= frameRemains:
            practice_mask.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in practiceComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "practice"-------
    for thisComponent in practiceComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if practice_response.keys in ['', [], None]:  # No response was made
        practice_response.keys=None
        # was no response the correct answer?!
        if str(correctAnswer).lower() == 'none':
           practice_response.corr = 1  # correct non-response
        else:
           practice_response.corr = 0  # failed to respond (incorrectly)
    # store data for practice_loop (TrialHandler)
    practice_loop.addData('practice_response.keys',practice_response.keys)
    practice_loop.addData('practice_response.corr', practice_response.corr)
    if practice_response.keys != None:  # we had a response
        practice_loop.addData('practice_response.rt', practice_response.rt)
    # the Routine "practice" was not non-slip safe, so reset the non-slip timer
    if practice_response.corr == 1:
        msg = "Correct!"
        print msg
    else:
        msg = "Incorrect!"
        print msg
    
    routineTimer.reset()
    
    
    # ------Prepare to start Routine "practice_feedback"-------
    t = 0
    practice_feedbackClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    routineTimer.add(2.000000)
    # update component parameters for each repeat
    feedback.setText(msg)
    # keep track of which components have finished
    practice_feedbackComponents = [feedback]
    for thisComponent in practice_feedbackComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "practice_feedback"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = practice_feedbackClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *feedback* updates
        if t >= 0.0 and feedback.status == NOT_STARTED:
            # keep track of start time/frame for later
            feedback.tStart = t
            feedback.frameNStart = frameN  # exact frame index
            feedback.setAutoDraw(True)
        frameRemains = 0.0 + 3- win.monitorFramePeriod * 0.75  # most of one frame period left
        if feedback.status == STARTED and t >= frameRemains:
            feedback.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in practice_feedbackComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "practice_feedback"-------
    for thisComponent in practice_feedbackComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.nextEntry()
    
# completed 1 repeats of 'practice_loop'


# ------Prepare to start Routine "starting"-------
t = 0
startingClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
begin_trials = event.BuilderKeyResponse()
# keep track of which components have finished
startingComponents = [starting_brief, begin_trials]
for thisComponent in startingComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "starting"-------
while continueRoutine:
    # get current time
    t = startingClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *starting_brief* updates
    if t >= 0.0 and starting_brief.status == NOT_STARTED:
        # keep track of start time/frame for later
        starting_brief.tStart = t
        starting_brief.frameNStart = frameN  # exact frame index
        starting_brief.setAutoDraw(True)
    
    # *begin_trials* updates
    if t >= 0.0 and begin_trials.status == NOT_STARTED:
        # keep track of start time/frame for later
        begin_trials.tStart = t
        begin_trials.frameNStart = frameN  # exact frame index
        begin_trials.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(begin_trials.clock.reset)  # t=0 on next screen flip
        event.clearEvents(eventType='keyboard')
    if begin_trials.status == STARTED:
        theseKeys = event.getKeys(keyList=['space'])
        
        # check for quit:
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0:  # at least one key was pressed
            begin_trials.keys = theseKeys[-1]  # just the last key pressed
            begin_trials.rt = begin_trials.clock.getTime()
            # a response ends the routine
            continueRoutine = False
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in startingComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "starting"-------
for thisComponent in startingComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if begin_trials.keys in ['', [], None]:  # No response was made
    begin_trials.keys=None
thisExp.addData('begin_trials.keys',begin_trials.keys)
if begin_trials.keys != None:  # we had a response
    thisExp.addData('begin_trials.rt', begin_trials.rt)
thisExp.nextEntry()
# the Routine "starting" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials = data.TrialHandler(nReps=1, method='fullRandom', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('trial_file.xlsx'),
    seed=None, name='trials')
thisExp.addLoop(trials)  # add the loop to the experiment
thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
if thisTrial != None:
    for paramName in thisTrial.keys():
        exec(paramName + '= thisTrial.' + paramName)

for trialNum,thisTrial in enumerate(trials):
    if trialNum > 0 and trialNum % 30 == 0 :
        breakText = visual.TextStim(win, color='white', height=0.03,text="Please take a short break. Press any key to continue.")
        breakText.draw()
        win.flip()
        event.waitKeys()
    currentLoop = trials
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial.keys():
            exec(paramName + '= thisTrial.' + paramName)
    
    # ------Prepare to start Routine "trial"-------
    t = 0
    trialClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    target1.setMask(u'None')
    target1.setPos(region)
    target1.setImage(target)
    stimulus_1.setPos(stim1pos)
    stimulus_1.setImage(stimulus1)
    stimulus_2.setPos(stim2pos)
    stimulus_2.setImage(stimulus2)
    keyResponse = event.BuilderKeyResponse()
    mask_real.setPos(region)
    mask_real.setImage(u'mask.gif')
    # keep track of which components have finished
    trialComponents = [target1, stimulus_1, stimulus_2, keyResponse, fixation, mask_real]
    for thisComponent in trialComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "trial"-------
    while continueRoutine:
        # get current time
        t = trialClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        #print what number trial you're on
           
        # *target1* updates
        if t >= 0.5 and  target1.status == NOT_STARTED:
            # keep track of start time/frame for later
            target1.tStart = t
            target1.frameNStart = frameN  # exact frame index
            target1.setAutoDraw(True)
        frameRemains = 0.5 + 0.2- win.monitorFramePeriod * 0.75  # most of one frame period left
        if target1.status == STARTED and t >= frameRemains:
            target1.setAutoDraw(False)
        
        # *stimulus_1* updates
        if t >= 1.15 and stimulus_1.status == NOT_STARTED:
            # keep track of start time/frame for later
            stimulus_1.tStart = t
            stimulus_1.frameNStart = frameN  # exact frame index
            stimulus_1.setAutoDraw(True)
        
        # *stimulus_2* updates
        if t >= 1.15 and stimulus_2.status == NOT_STARTED:
            # keep track of start time/frame for later
            stimulus_2.tStart = t
            stimulus_2.frameNStart = frameN  # exact frame index
            stimulus_2.setAutoDraw(True)
        
        # *keyResponse* updates
        if t >= 1.15 and keyResponse.status == NOT_STARTED:
            # keep track of start time/frame for later
            keyResponse.tStart = t
            keyResponse.frameNStart = frameN  # exact frame index
            keyResponse.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(keyResponse.clock.reset)  # t=0 on next screen flip
            event.clearEvents(eventType='keyboard')
        if keyResponse.status == STARTED:
            theseKeys = event.getKeys(keyList=['num_1', 'num_2'])
            
            # check for quit:
            if "escape" in theseKeys:
                endExpNow = True
            if len(theseKeys) > 0:  # at least one key was pressed
                keyResponse.keys = theseKeys[-1]  # just the last key pressed
                keyResponse.rt = keyResponse.clock.getTime()
                # was this 'correct'?
                if (keyResponse.keys == str(correctAnswer)) or (keyResponse.keys == correctAnswer):
                    keyResponse.corr = 1
                else:
                    keyResponse.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *fixation* updates
        if t >= 0.0 and fixation.status == NOT_STARTED:
            # keep track of start time/frame for later
            fixation.tStart = t
            fixation.frameNStart = frameN  # exact frame index
            fixation.setAutoDraw(True)
        
        # *mask_real* updates
        if t >= 0.7 and mask_real.status == NOT_STARTED:
            # keep track of start time/frame for later
            mask_real.tStart = t
            mask_real.frameNStart = frameN  # exact frame index
            mask_real.setAutoDraw(True)
        frameRemains = 0.7 + .45- win.monitorFramePeriod * 0.75  # most of one frame period left
        if mask_real.status == STARTED and t >= frameRemains:
            mask_real.setAutoDraw(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "trial"-------
    for thisComponent in trialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if keyResponse.keys in ['', [], None]:  # No response was made
        keyResponse.keys=None
        # was no response the correct answer?!
        if str(correctAnswer).lower() == 'none':
           keyResponse.corr = 1  # correct non-response
        else:
           keyResponse.corr = 0  # failed to respond (incorrectly)
    #print message
    loopCounter = loopCounter + 1
    print loopCounter
    
    # store data for trials (TrialHandler)
    trials.addData('keyResponse.keys',keyResponse.keys)
    trials.addData('keyResponse.corr', keyResponse.corr)
    if keyResponse.keys != None:  # we had a response
        trials.addData('keyResponse.rt', keyResponse.rt)
    # the Routine "trial" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1 repeats of 'trials'


# ------Prepare to start Routine "debrief"-------
t = 0
debriefClock.reset()  # clock
frameN = -1
continueRoutine = True
routineTimer.add(1.000000)
# update component parameters for each repeat
# keep track of which components have finished
debriefComponents = [text]
for thisComponent in debriefComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "debrief"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = debriefClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text* updates
    if t >= 0.0 and text.status == NOT_STARTED:
        # keep track of start time/frame for later
        text.tStart = t
        text.frameNStart = frameN  # exact frame index
        text.setAutoDraw(True)
    frameRemains = 0.0 + 1.0- win.monitorFramePeriod * 0.75  # most of one frame period left
    if text.status == STARTED and t >= frameRemains:
        text.setAutoDraw(False)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in debriefComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "debrief"-------
for thisComponent in debriefComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
